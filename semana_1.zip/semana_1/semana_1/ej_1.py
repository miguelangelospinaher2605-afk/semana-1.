nota = int(input("Ingresa tu nota(1 a 10)"));
if (nota > 6):
    print("Has aprobado")
else:
    print("Has reprobado");