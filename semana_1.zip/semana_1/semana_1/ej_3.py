numero = int(input("Ingresa un numero entero: "))
if (numero > 0):
    print("Numero es positivo")
else:
    print("El numero noi es positivo");