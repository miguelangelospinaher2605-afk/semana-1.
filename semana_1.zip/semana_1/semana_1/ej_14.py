stock = int(input("Ingrese la cantidad de unidades disponibles: "))

if stock < 5:
    print("Alerta: Realizar pedido de reabastecimiento")
else:
    print("Stock suficiente disponible")