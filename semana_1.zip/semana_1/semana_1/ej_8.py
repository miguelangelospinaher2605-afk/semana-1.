velocidad = int(input("Ingresa la velocidad en km/h: "))
if ("velocidad > 120"):
    print("Alerta: Ha puesto el limite de velocidad ")
else:
    print("Velocidad dentro del limite permitido");