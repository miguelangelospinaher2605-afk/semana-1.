puntaje = float(input("Ingrese el puntaje obtenido (0 a 100): "))

if puntaje >= 80:
    print("Apto para licencia")
else:
    print("Debes repetir el examen")