monto = int(input("Ingrese el monto de tu compra: "))
if (monto > 1000000):
    print("¡Felicitaciones! Ganaste un cupon de regalo")
else:
    print("Gracias por tu compra (no alcanza tu cupon de regalo)");