temperatura = float(input("Ingrese la temperatura corporal en °C: "))

if temperatura > 37.5:
    print("Presenta fiebre")
else:
    print("Temperatura dentro del rango normal")