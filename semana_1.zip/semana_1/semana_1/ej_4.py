temp = int(input("Ingresa la temperatura acutual en °C: "))
if (temp > 30):
    print("Hace alor, recuerda hidratqarte")
else:
    print("Temperatura templada y fresca");